export function Age({children}) {

    return (
        <>
        <span>{children}</span>
        </>
    )
}